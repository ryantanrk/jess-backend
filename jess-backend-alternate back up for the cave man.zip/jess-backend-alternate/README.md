# jess-backend
Repo for JESS backend

CSCI334 Group Project

# Group 5
- Ryan Tan Rui Kit
- Lye Tian-Yong
- Mohammed Azizul Hoque Sheikh
- Sun Chao
- Wu Fuyun


Using Object-Oriented PHP

Design patterns: State (Behavioral), Factory Method (Creational)

Pairs with frontend: [Link](https://github.com/ryantanrk/jess-frontend)
