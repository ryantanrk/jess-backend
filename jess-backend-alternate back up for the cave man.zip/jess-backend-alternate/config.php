<?php
    //database login credentials
    $server = 'localhost';
    $connectUser = 'root';
    $connectPass = '';

    //database config
    $database = 'jess'; //database name
    
    //table names
    $documentTable = 'document';
    $personTable = 'person';
    $reviewTable = 'review';
    $reviewerTable = 'reviewerspecific';

    $email = "survxyzburner@gmail.com";
?>